#include <ros/ros.h>
#include <geometry_msgs/Twist.h>

int main(int argc, char **argv)
{
    ros::init(argc, argv, "squarehw");
    
    ros::NodeHandle n;

    ros::Publisher turtle_vel_pub = n.advertise<geometry_msgs::Twist>("/turtle1/cmd_vel", 10);

    ros::Rate loop_rate(1);
    

    int count = 0;
    while(ros::ok())
    {
    	for(int i = 0; i < 5; i++)
	{	
		geometry_msgs::Twist mov_msg;
		mov_msg.linear.x = 3.0;
		turtle_vel_pub.publish(mov_msg);
		ROS_INFO("Move for 2 seconds");
		ros::Duration(2).sleep();
		
		geometry_msgs::Twist still_msg;
		still_msg.linear.x = 0.0;
		turtle_vel_pub.publish(still_msg);
		ROS_INFO("Be still for 1 seconds");
		ros::Duration(1).sleep();
		
		geometry_msgs::Twist turn_msg;
		turn_msg.angular.z = 1.57;
		turtle_vel_pub.publish(turn_msg);
		ROS_INFO("Turn 90 degrees");
		ros::Duration(2).sleep();
		
		turtle_vel_pub.publish(still_msg);
		ROS_INFO("Be still for 1 seconds");
		ros::Duration(1).sleep();
        
	}
      
        break;
        
    }
    return 0;
}
